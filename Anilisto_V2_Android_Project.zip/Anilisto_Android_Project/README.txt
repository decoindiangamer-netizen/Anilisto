ANILISTO V2 — ANDROID PROJECT

This is a native Android APK project. The app is a local Android WebView shell containing the Anilisto interface and tracker.

FEATURES
- Premium dark-purple UI
- Anime discovery search using the public Jikan API (internet required)
- Poster art, genres, episode counts, synopsis and scores when returned by the API
- Personal library, custom anime entries, watched episode tracking
- Watching / Plan to watch / Completed / On Hold
- Search, filter, sort, progress and JSON backup
- LocalStorage progress persists on the device; saved library remains usable offline
- APK build workflow included at .github/workflows/android.yml

BUILD APK (cloud build)
1. Create a GitHub repository and upload the CONTENTS of this project ZIP.
2. Open the repository's Actions tab.
3. Run "Build Anilisto APK" (or push to main).
4. Open the completed workflow run and download the "Anilisto-debug-apk" artifact.
5. Extract the artifact ZIP; install app-debug.apk on your Android device. Android may ask you to allow installation from that source.

BUILD LOCALLY
Requires Android SDK (platform 35), JDK 17, and Gradle 8.9. Run: gradle assembleDebug

LIMITATIONS / HONEST NOTES
- This package is Android source plus an automated APK build workflow; it is not itself a precompiled APK.
- Online discovery uses Jikan (MyAnimeList-derived public API) and requires internet. API rate limits or downtime can temporarily affect search.
- Anime catalogue is searchable rather than literally exhaustive; no service can guarantee every anime title.
- Poster images are loaded from API image URLs; offline mode shows saved titles but remote posters may not be cached.
- The APK produced by the workflow is a debug APK, suitable for personal testing, not a Play Store release-signed build.
